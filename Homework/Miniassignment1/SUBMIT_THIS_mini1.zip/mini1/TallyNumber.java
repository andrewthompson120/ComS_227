package mini1;


public class TallyNumber {
	
	private int userValue = 0; // Gets the user value in the constructor
	private String userString = ""; // Gets the user string from the constructor
	private int currentIntTally = 0; // Running int tally
	private String currentStrTally = ""; // Running String tally 
	private int tempInt = 0;
	private String tempStr = "";
	
	/**
	 * Constructs a tally number with the given integer value.
	 * @param givenValue
	 */
	public TallyNumber(int givenValue) {
		userValue = givenValue;
		currentIntTally = userValue;
		userString = normalizeString(userValue);
		currentStrTally = userString;
		brokenString(currentStrTally);	
		if(currentIntTally < 0) {
			currentStrTally = "";
			currentIntTally = -1;
		}
	}
	
	/**
	 * Constructs a TallyNumber with the given string representation.
	 * @param givenString
	 */
	public TallyNumber(String givenString) {
		userString = givenString;
		currentStrTally = userString;
		userValue = normalizeInt(userString);
		currentIntTally = userValue;
		brokenString(currentStrTally);
		if(currentIntTally < 0) {
			currentStrTally = "";
			currentIntTally = -1;
		}
	}
	
	/**
	 * Adds the value of the given TallyNumber to this one. 
	 * After the operation, this TallyNumber's value will be the sum of this 
	 * and the given number, and its representation will the fully normalized form. 
	 * The given TallyNumber is not modified.
	 * @param other (int)
	 */
	public void add(TallyNumber other) {
		tempInt = other.getIntValue();
		currentIntTally = currentIntTally + tempInt;
	}
	
	/**
	 * Add the given TallyNumber to this one by concatenating the corresponding 
	 * tally groups. After the operation, this TallyNumber's value will be the 
	 * sum of this and the given number, and its representation will consist of 
	 * each of this number's tally groups concatenated with the corresponding 
	 * tally group from the given number's representation. The given 
	 * TallyNumber is not modified.
	 * @param other
	 */
	public void combine(TallyNumber other) {
		tempStr = other.getStringValue();
		currentStrTally = currentStrTally + tempStr;
	}
	
	/**
	 * Converts this TallyNumber's representation to its normalized 
	 * form without changing the value.
	 */
	public void normalize() {
		currentIntTally = normalizeInt(currentStrTally);
	}
	
	/**
	 * Returns the integer value of this tally number.
	 */
	public int getIntValue() {
		return currentIntTally;
	}
	
	/**
	 * Returns the string representation of this tally number.
	 */
	public String getStringValue() {
		return currentStrTally;
	}
	
	
	/**
	 * Method that returns the normalized int from the string
	 * @param input
	 * @return total (aka normalized int)
	 */
	private int normalizeInt(String input) {
		String inputString = input;
		int total = 0;
		int fives = 0;
		int ones = 0;
		int digit = 1;
		
		if (inputString.length()  == 0) {
			return -1;
		}
		
		
		for (int i = inputString.length() - 1; i > -1; i--) {
			
			if (inputString.charAt(i) == '*') {
				fives++;
			}
			else if (inputString.charAt(i) == '|') {
				ones++;
			}
			else if (inputString.charAt(i) == ' ') {
				total = total + (fives * 5 + ones) * tenPower(digit);
				digit++;
				ones = 0;
				fives = 0;
			}
			else if(inputString.charAt(i) == '0') {
				
			}
			else {
				currentStrTally = "";
				return -1;
			}
			
			
		}
		total = total + (fives * 5 + ones) * tenPower(digit);
		
		return total;
		
	}
	
	/**
	 * Method that normalizes string. It is separate since it is called many times;
	 * @param input
	 * @return tallyString (aka normallized string)
	 */
	private String normalizeString(int input) {
		String tallyString = "";
		int numberInput = input;
		String numberAsString = Integer.toString(numberInput);
		int digit = 0;
		int five = 0;
		int ones = 0;
		if(numberInput == 0) {
			return "0";
		}
		
		for(int i = 0; i < numberAsString.length(); i++) {
			
			digit = numberAsString.charAt(i)-48;
			System.out.println(digit);
			five = digit / 5;
			ones = digit % 5;
			System.out.println(five);
			if((five == 0) && (ones == 0)) {
				tallyString = tallyString + "0";
			}
			else if (five > 0) {
				for (int j = 0; j < five; j++) {
					tallyString = tallyString + "*";
				}
			}
			else if (ones > 0) {
				for (int f = 0; f < ones; f++) {
					tallyString = tallyString + "|";
				}
			}
			else {
				return "";
			}
			
			tallyString = tallyString + " ";
			
		}
		
		return tallyString;
		
	}
	
	private int tenPower(int power) {
		int exponent = power - 1;
		int answer = 1;
		for (int b = 0; b < exponent; b++) {
			answer = answer * 10;
		}
		return answer;
	}
	
	private String brokenString(String input) {
		String inputString = input;
		for (int i = 0; i < inputString.length();i++) {
			//if(!((inputString.charAt(i) == '|') || (inputString.charAt(i) == ' ') || (inputString.charAt(i) == '*') || (inputString.charAt(i) == '0'))) {
				//inputString = "";
		//	}
		}
		return inputString;
	}
}
